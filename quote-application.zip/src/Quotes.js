import React from "react";

export function LikedQuotes({ likedQuotes }) {
  return (
    <>
      <h1>
        <center>Liked Quotes</center>
      </h1>
      <div className="likedQuotes">
        {likedQuotes.length === 0 ? (
          <h3>
            <center>No liked quotes</center>
          </h3>
        ) : (
          likedQuotes.map((quote, index) => <Quote key={index} quote={quote} />)
        )}
      </div>
    </>
  );
}

function Quote({ quote }) {
  return (
    <div className="card">
      <i className="fa fa-quote-left"></i>
      <div className="quotes">{quote.body}</div>
      <div className="author">-{quote.author}</div>
    </div>
  );
}

export function Quotes({
  isLoading,
  isError,
  quoteData,
  refreshData,
  setLiked,
  likedQuotes,
  clearLiked,
}) {
  const { quote: { body, author } = {} } = quoteData || {};

  function storeLike() {
    setLiked({
      body,
      author,
    });
  }

  function getSucessSection() {
    return (
      <>
        <i className="fa fa-quote-left"></i>
        <div className="quotes">{body}</div>
        <div className="author">-{author}</div>
      </>
    );
  }

  return (
    <div className="container">
      <div className="card">
        {isLoading && <i className="fa fa-spinner" />}
        {isError && <i className="fa fa-times-circle" />}
        {!isLoading && !isError && quoteData && getSucessSection()}
      </div>
      <div className="action">
        {quoteData && <i onClick={storeLike} className="fa fa-thumbs-o-up" />}
        <i
          onClick={refreshData}
          className="fa fa-refresh"
          aria-hidden="true"
        ></i>
        {likedQuotes.length > 0 && (
          <i className="fa fa-times-circle" onClick={clearLiked} />
        )}
      </div>
    </div>
  );
}
