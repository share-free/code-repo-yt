import { DataProvider } from "./DataProvider";
import { Quotes, LikedQuotes } from "./Quotes";
import "./App.css";
import { useState, useEffect } from "react";

const localStorageKey = "quotes";

function App() {
  const Url = "https://favqs.com/api/qotd";
  const [refresh, setRefresh] = useState(false);
  const [likedQuotes, setLikedQuotes] = useState([]);

  useEffect(() => {
    const localQuotes = JSON.parse(localStorage.getItem(localStorageKey)) || [];
    setLikedQuotes(localQuotes);
  }, []);

  function setLiked(value) {
    const presentValues =
      JSON.parse(localStorage.getItem(localStorageKey)) || [];
    const updatedValues = [...presentValues, value];
    localStorage.setItem(localStorageKey, JSON.stringify(updatedValues));
    setLikedQuotes(updatedValues);
  }

  function clearLiked() {
    localStorage.setItem(localStorageKey, JSON.stringify([]));
    setLikedQuotes([]);
  }

  function refreshData() {
    setRefresh(!refresh);
  }

  return (
    <>
      <DataProvider
        refresh={refresh}
        url={Url}
        render={(isLoading, isError, data) => (
          <Quotes
            isLoading={isLoading}
            isError={isError}
            quoteData={data}
            refreshData={refreshData}
            setLiked={setLiked}
            likedQuotes={likedQuotes}
            clearLiked={clearLiked}
          />
        )}
      />
      <LikedQuotes likedQuotes={likedQuotes} />
    </>
  );
}

export default App;

// Thanks for watching :)
