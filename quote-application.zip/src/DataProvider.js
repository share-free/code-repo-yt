import React, { useEffect, useState } from "react";

export function DataProvider({ url, render, refresh }) {
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState(null);
  const [isError, setIsError] = useState(false);

  function resetFetching() {
    setIsLoading(false);
    setIsError(false);
    setData(null);
  }

  function setError() {
    setIsLoading(false);
    setIsError(true);
    setData(null);
  }

  useEffect(() => {
    async function fetchData() {
      try {
        resetFetching();
        setIsLoading(true);
        const response = await fetch(url);
        const jsonResponse = await response.json();
        setIsLoading(false);
        setIsError(false);
        setData(jsonResponse);
      } catch (err) {
        setError();
      }
    }

    fetchData();
  }, [refresh]);

  return render(isLoading, isError, data);
}
